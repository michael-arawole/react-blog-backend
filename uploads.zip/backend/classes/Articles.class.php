<?php 
// +------------------------------------------------------------------------+
// | @author        : Michael Arawole (Logad Networks)
// | @author_url    : https://www.logad.net
// | @author_email  : logadscripts@gmail.com
// | @date          : 19 Sep, 2022 03:05PM
// +------------------------------------------------------------------------+

// +----------------------------+
// | Articles
// +----------------------------+

class Articles extends DB {
	private static $tableName = 'articles';

	public static function getRecent() {
		try {
			return (new DB('articles'))
				->selectAll(20);
		}
		catch (Exception $e) {
			// echo $e->getMessage();
			return [];
		}
	}

	## Get article by id ##
	public static function byID($article_id) {
		return (new DB(self::$tableName))
			->where([
				"id" => $article_id
			])
			->select();
	}

	## Delete article by id ##
	public static function delete($article_id) {
		return (new DB(self::$tableName))
			->deleteWhere([
				"id" => $article_id
			]);
	}

	public static function store($data) {
		$response['message'] = "Failed to store new article";
		$response['status'] = false;

		$db = new DB(self::$tableName);
		$imagepath = APP_BASE."uploads/images/".date('Y-M')."/";
		if (!file_exists($imagepath)) {
			mkdir($imagepath, 0777, true);
		}
		$filename = $imagepath.time().".png";
		file_put_contents($filename, file_get_contents($data->imageUrl));
		$insertID = $db->setColumnsAndValues([
				"title" => $data->title,
				"author" => $data->author,
				"content" => htmlentities($data->content),
				"image" => 'https://react-blog.test/'.str_replace(APP_BASE, '', $filename)
			])
			->insert();
		if (!empty($insertID)) {
			$response['status'] = true;
			$response['message'] = "success";
			$response['data'] = self::byID($insertID);
		} else {
			$response['message'] = $db->getErrors();
		}
		return $response;
	}
}